<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

$routes->get('/', 'Home::index');

$routes->post('/save-customer', 'Home::saveCustomer');

$routes->get('/products', 'Product::index');
$routes->get('/product/(:num)', 'Product::detail/$1');

$routes->post('/cart/add', 'Cart::add');
$routes->get('/cart', 'Cart::index');
$routes->get('/cart/increase/(:num)', 'Cart::increase/$1');
$routes->get('/cart/decrease/(:num)', 'Cart::decrease/$1');
$routes->post('/cart/update', 'Cart::update');
$routes->get('/cart/remove/(:num)', 'Cart::remove/$1');

$routes->get('/checkout', 'Checkout::index');
$routes->post('/checkout/process', 'Checkout::process');

$routes->get('/history', 'History::index');