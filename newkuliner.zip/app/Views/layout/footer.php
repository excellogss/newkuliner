<footer class="bg-white mt-20 border-t border-gray-200">

    <div class="container mx-auto px-4 py-16">

        <div class="grid lg:grid-cols-4 gap-10">

            <div class="lg:col-span-1">

                <h3 class="text-3xl font-bold leading-tight mb-5">

                    Ordering from your favorite restaurant more easier

                </h3>

                <p class="text-gray-500 leading-relaxed">

                    Nikmati pengalaman pesan makanan yang modern,
                    cepat, dan nyaman langsung dari meja Anda.

                </p>

            </div>

            <div>

                <h4 class="font-bold text-lg mb-5">
                    ABOUT
                </h4>

                <div class="flex flex-col gap-4 text-gray-500">

                    <a href="#"
                       class="hover:text-[#EF7722] transition">
                        About Us
                    </a>

                    <a href="#"
                       class="hover:text-[#EF7722] transition">
                        How to work
                    </a>

                    <a href="#"
                       class="hover:text-[#EF7722] transition">
                        Blog
                    </a>

                </div>

            </div>

            <div>

                <h4 class="font-bold text-lg mb-5">
                    BE OFFICIAL RESTO
                </h4>

                <div class="flex flex-col gap-4 text-gray-500">

                    <a href="#"
                       class="hover:text-[#EF7722] transition">
                        Get Started
                    </a>

                    <a href="#"
                       class="hover:text-[#EF7722] transition">
                        Learn More
                    </a>

                    <a href="#"
                       class="hover:text-[#EF7722] transition">
                        Download POS
                    </a>

                </div>

            </div>

            <div>

                <h4 class="font-bold text-lg mb-5">
                    TERM
                </h4>

                <div class="flex flex-col gap-4 text-gray-500">

                    <a href="#"
                       class="hover:text-[#EF7722] transition">
                        Privacy Policy
                    </a>

                    <a href="#"
                       class="hover:text-[#EF7722] transition">
                        Terms and Condition
                    </a>

                </div>

            </div>

        </div>

        <div class="border-t border-gray-200 mt-14 pt-8">

            <div class="flex flex-col md:flex-row gap-4 justify-between items-center">

                <p class="text-gray-500 text-sm text-center md:text-left">

                    © <?= date('Y') ?> NewKuliner.
                    All rights reserved.

                </p>

                <div class="flex items-center gap-3">

                    <div class="w-10 h-10 rounded-2xl bg-[#EBEBEB] hover:bg-[#EF7722] hover:text-white transition flex items-center justify-center cursor-pointer">

                        <svg xmlns="http://www.w3.org/2000/svg"
                             class="w-5 h-5"
                             fill="currentColor"
                             viewBox="0 0 24 24">

                            <path d="M22 12a10 10 0 10-11.56 9.88v-6.99H7.9V12h2.54V9.8c0-2.5 1.5-3.89 3.78-3.89 1.09 0 2.23.19 2.23.19v2.46h-1.26c-1.24 0-1.63.77-1.63 1.56V12h2.77l-.44 2.89h-2.33v6.99A10 10 0 0022 12z"/>

                        </svg>

                    </div>

                    <div class="w-10 h-10 rounded-2xl bg-[#EBEBEB] hover:bg-[#EF7722] hover:text-white transition flex items-center justify-center cursor-pointer">

                        <svg xmlns="http://www.w3.org/2000/svg"
                             class="w-5 h-5"
                             fill="currentColor"
                             viewBox="0 0 24 24">

                            <path d="M7.75 2C4.57 2 2 4.57 2 7.75v8.5C2 19.43 4.57 22 7.75 22h8.5C19.43 22 22 19.43 22 16.25v-8.5C22 4.57 19.43 2 16.25 2h-8.5zm0 1.8h8.5a3.95 3.95 0 013.95 3.95v8.5a3.95 3.95 0 01-3.95 3.95h-8.5a3.95 3.95 0 01-3.95-3.95v-8.5A3.95 3.95 0 017.75 3.8zm8.85 1.35a1.08 1.08 0 100 2.16 1.08 1.08 0 000-2.16zM12 7a5 5 0 100 10 5 5 0 000-10zm0 1.8A3.2 3.2 0 1112 15.2 3.2 3.2 0 0112 8.8z"/>

                        </svg>

                    </div>

                </div>

            </div>

        </div>

    </div>

</footer>

</body>
</html>