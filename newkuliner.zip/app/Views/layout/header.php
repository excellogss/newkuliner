<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>NewKuliner</title>

    <script src="https://cdn.tailwindcss.com"></script>

    <link rel="preconnect"
          href="https://fonts.googleapis.com">

    <link rel="preconnect"
          href="https://fonts.gstatic.com"
          crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap"
          rel="stylesheet">

    <link rel="stylesheet"
          href="<?= base_url('assets/css/style.css') ?>">

</head>

<body class="bg-[#EBEBEB] text-gray-800">

<?php

$cart = session()->get('cart') ?? [];

$totalItem = 0;

foreach($cart as $item){

    $totalItem += $item['qty'];

}

?>

<nav class="sticky top-0 z-40 bg-white/90 backdrop-blur-lg border-b border-gray-100">

    <div class="container mx-auto px-4">

        <div class="h-[72px] flex items-center justify-between">

            <a href="<?= base_url() ?>"
               class="flex items-center gap-3">

                <div>

                    <h1 class="font-extrabold text-xl leading-none">
                        NewKuliner
                    </h1>

                    <!--p class="text-xs text-gray-500">
                        Restaurant Premium
                    </p -->

                </div>

            </a>

            <div class="flex items-center gap-3">

                <a href="<?= base_url('cart') ?>"
                   class="relative flex items-center justify-center bg-[#EF7722] hover:bg-[#FAA533] transition w-11 h-11 rounded-2xl text-white">

                    <svg xmlns="http://www.w3.org/2000/svg"
                         class="w-6 h-6"
                         fill="none"
                         viewBox="0 0 24 24"
                         stroke="currentColor">

                        <path stroke-linecap="round"
                              stroke-linejoin="round"
                              stroke-width="2"
                              d="M3 3h2l.4 2M7 13h10l4-8H5.4m1.6 8L5.4 5M7 13l-1.293 1.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"/>

                    </svg>

                    <?php if($totalItem > 0): ?>

                        <span class="absolute -top-2 -right-2 min-w-[22px] h-[22px] px-1 bg-[#0BA6DF] text-white text-xs font-bold rounded-full flex items-center justify-center"  id="cartCount">
                            <?= $totalItem ?>
                        </span>

                    <?php endif; ?>

                </a>

                <div class="relative">

                    <button
                        onclick="toggleNavbarMenu()"
                        class="w-11 h-11 rounded-2xl border border-gray-200 bg-white hover:border-[#EF7722] transition flex items-center justify-center">

                        <svg xmlns="http://www.w3.org/2000/svg"
                             class="w-6 h-6"
                             fill="none"
                             viewBox="0 0 24 24"
                             stroke="currentColor">

                            <path stroke-linecap="round"
                                  stroke-linejoin="round"
                                  stroke-width="2"
                                  d="M4 6h16M4 12h16M4 18h16"/>

                        </svg>

                    </button>

                    <div
                        id="navbarMenu"
                        class="hidden absolute right-0 top-14 w-[250px] bg-white rounded-3xl shadow-xl border border-gray-100 overflow-hidden">

                        <button
                            onclick="openCustomerModal()"
                            class="w-full flex items-center gap-4 px-5 py-4 hover:bg-gray-50 transition text-left">

                            <div class="w-11 h-11 rounded-2xl bg-[#EF7722]/10 text-[#EF7722] flex items-center justify-center">

                                <svg xmlns="http://www.w3.org/2000/svg"
                                     class="w-6 h-6"
                                     fill="none"
                                     viewBox="0 0 24 24"
                                     stroke="currentColor">

                                    <path stroke-linecap="round"
                                          stroke-linejoin="round"
                                          stroke-width="2"
                                          d="M5.121 17.804A9 9 0 1118.364 4.56M15 11a3 3 0 11-6 0 3 3 0 016 0zm6 10a9 9 0 10-18 0h18z"/>

                                </svg>

                            </div>

                            <div>

                                <h4 class="font-semibold">
                                    <?= session()->get('customer_name') ?? 'Pesan' ?>
                                </h4>

                                <p class="text-sm text-gray-500">
                                    Pesan Baru
                                </p>

                            </div>

                        </button>

                        <a
                            href="<?= base_url('history') ?>"
                            class="flex items-center gap-4 px-5 py-4 hover:bg-gray-50 transition">

                            <div class="w-11 h-11 rounded-2xl bg-[#0BA6DF]/10 text-[#0BA6DF] flex items-center justify-center">

                                <svg xmlns="http://www.w3.org/2000/svg"
                                     class="w-6 h-6"
                                     fill="none"
                                     viewBox="0 0 24 24"
                                     stroke="currentColor">

                                    <path stroke-linecap="round"
                                          stroke-linejoin="round"
                                          stroke-width="2"
                                          d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>

                                </svg>

                            </div>

                            <div>

                                <h4 class="font-semibold">
                                    Riwayat
                                </h4>

                                <p class="text-sm text-gray-500">
                                    Riwayat Transaksi
                                </p>

                            </div>

                        </a>

                    </div>

                </div>

            </div>

        </div>

    </div>

</nav>

<script>

function toggleNavbarMenu()
{
    document.getElementById('navbarMenu').classList.toggle('hidden');
}

window.addEventListener('click', function(e){

    const menu = document.getElementById('navbarMenu');

    if(
        !e.target.closest('#navbarMenu') &&
        !e.target.closest('button')
    ){
        menu.classList.add('hidden');
    }

});

function openCustomerModal()
{
    const modal = document.getElementById('customerModal');

    if(modal){

        modal.style.display = 'flex';

    }
}

</script>