<?= $this->include('layout/header') ?>

<div class="container mx-auto px-4 py-8 min-h-screen">

    <div class="flex items-center justify-between mb-8">

        <div>

            <h1 class="text-4xl font-bold mb-2">
                Riwayat
            </h1>

        </div>

        <a href="<?= base_url() ?>"
           class="bg-[#EF7722] hover:bg-[#FAA533] transition text-white px-6 h-12 rounded-2xl flex items-center font-semibold">

            Kembali

        </a>

    </div>

    <div class="space-y-5">

        <?php foreach($transactions as $trx): ?>

            <div class="bg-white rounded-3xl p-5 md:p-6 shadow-sm">

                <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-5 mb-6">

                    <div>

                        <div class="flex items-center gap-3 mb-3">

                            <span class="bg-[#FFF7F0] text-[#EF7722] px-4 py-2 rounded-full text-sm font-semibold">

                                <?= $trx['invoice'] ?>

                            </span>

                            <?php if($trx['status'] == 'PAID'): ?>

                                <span class="bg-green-100 text-green-600 px-4 py-2 rounded-full text-sm font-semibold">

                                    Lunas

                                </span>

                            <?php else: ?>

                                <span class="bg-yellow-100 text-yellow-600 px-4 py-2 rounded-full text-sm font-semibold">

                                    Pending

                                </span>

                            <?php endif; ?>

                        </div>

                        <h3 class="text-2xl font-bold mb-2">

                            <?= $trx['customer_name'] ?>

                        </h3>

                        <p class="text-gray-500">

                            <?= $trx['created_at'] ?>

                        </p>

                    </div>

                    <div class="text-left md:text-right">

                        <p class="text-sm text-gray-500 mb-2">
                            Total Pembayaran
                        </p>

                        <h3 class="text-3xl font-bold text-[#EF7722]">

                            Rp<?= number_format($trx['total'],0,',','.') ?>

                        </h3>

                    </div>

                </div>

                <div class="border-t border-gray-100 pt-5 space-y-4">

                    <?php foreach($trx['items'] as $item): ?>

                        <div class="flex items-center justify-between gap-4">

                            <div class="flex items-center gap-4 min-w-0">

                                <div class="w-14 h-14 rounded-2xl bg-[#F5F5F5] flex items-center justify-center shrink-0">

                                    🍔

                                </div>

                                <div class="min-w-0">

                                    <h4 class="font-bold truncate">

                                        <?= $item['name'] ?>

                                    </h4>

                                    <p class="text-sm text-gray-500">

                                        <?= $item['qty'] ?>x menu

                                    </p>

                                </div>

                            </div>

                            <div class="text-right shrink-0">

                                <h4 class="font-bold text-[#EF7722]">

                                    Rp<?= number_format($item['price'] * $item['qty'],0,',','.') ?>

                                </h4>

                            </div>

                        </div>

                    <?php endforeach; ?>

                </div>

                <div class="border-t border-gray-100 mt-6 pt-5 flex flex-col md:flex-row md:items-center md:justify-between gap-4">

                    <div class="flex items-center gap-3 text-sm text-gray-500">

                        <span>
                            Metode:
                        </span>

                        <span class="font-semibold text-gray-700">
                            QRIS
                        </span>

                    </div>

                    <button
                        class="bg-[#FFF7F0] hover:bg-[#EF7722] hover:text-white transition text-[#EF7722] px-5 h-11 rounded-2xl font-semibold">

                        Detail Pesanan

                    </button>

                </div>

            </div>

        <?php endforeach; ?>

    </div>

    <?php if(empty($transactions)): ?>

        <div class="bg-white rounded-3xl p-12 text-center">

            <div class="text-6xl mb-5">
                📄
            </div>

            <h3 class="text-3xl font-bold mb-3">
                Belum Ada Transaksi
            </h3>

            <p class="text-gray-500 mb-8">
                History transaksi customer akan muncul disini
            </p>

            <a href="<?= base_url() ?>"
               class="bg-[#EF7722] hover:bg-[#FAA533] transition text-white px-6 h-12 rounded-2xl inline-flex items-center font-semibold">

                Mulai Pesan

            </a>

        </div>

    <?php endif; ?>

</div>

<?= $this->include('layout/footer') ?>