<?= $this->include('layout/header') ?>

<?php

$subtotal = $total;
$ppn = $subtotal * 0.11;
$service = $subtotal * 0.05;
$grandTotal = $subtotal + $ppn + $service;

?>

<div class="container mx-auto px-4 py-6 md:py-10 pb-40 min-h-screen">

    <!-- HEADER -->
    <div class="flex items-center justify-between mb-8">

        <h1 class="text-3xl md:text-4xl font-bold">
            Pesanan
        </h1>

        <a href="<?= base_url() ?>"
           class="bg-white border-2 border-[#EF7722] text-[#EF7722] hover:bg-[#EF7722] hover:text-white transition px-5 h-12 rounded-2xl flex items-center font-semibold whitespace-nowrap">

            + Tambah Item

        </a>

    </div>

    <?php if(empty($cart)): ?>

        <div class="bg-white rounded-3xl p-10 text-center">

            <h3 class="text-2xl font-bold mb-3">
                Cart Kosong
            </h3>

            <p class="text-gray-500 mb-8">
                Yuk pilih menu favoritmu 🍔
            </p>

            <a href="<?= base_url() ?>"
               class="bg-[#EF7722] hover:bg-[#FAA533] transition text-white px-6 h-12 rounded-2xl inline-flex items-center font-semibold">

                Kembali Belanja

            </a>

        </div>

    <?php else: ?>

        <div class="grid lg:grid-cols-3 gap-8">

            <!-- LEFT -->
            <div class="lg:col-span-2 space-y-5">

                <?php foreach($cart as $item): ?>

                    <div id="cart-item-<?= $item['id'] ?>" data-price="<?= $item['price'] ?>" class="cart-item bg-white rounded-3xl p-4 md:p-5">
                        

                        <div class="flex gap-4">

                            <!--
                            <img src="<?= $item['image'] ?>"
                                 class="w-24 h-24 rounded-2xl object-cover shrink-0">
                            -->

                            <div class="flex-1 min-w-0">

                                <h3 class="font-bold text-lg md:text-xl mb-2 leading-tight">

                                    <?= $item['name'] ?>

                                </h3>

                                <p class="text-[#EF7722] font-bold text-lg mb-4">

                                    Rp<?= number_format($item['price'],0,',','.') ?>

                                </p>

                                <?php if(!empty($item['note'])): ?>

                                    <div class="bg-[#EBEBEB] rounded-2xl px-4 py-3 text-sm text-gray-600">

                                        Note: <?= $item['note'] ?>

                                    </div>

                                <?php endif; ?>

                            </div>

                        </div>

                        <!-- ACTION -->
                        <div class="flex items-center justify-between mt-5 pt-5 border-t border-gray-100">

                            <button
                                onclick="removeCart(<?= $item['id'] ?>)"
                                class="text-red-500 text-sm font-semibold">

                                Hapus

                            </button>

                            <div class="flex items-center gap-3 bg-[#EBEBEB] rounded-2xl px-3 py-2">

                                <button
                                    onclick="updateQty(<?= $item['id'] ?>, 'decrease')"
                                    class="w-9 h-9 rounded-xl bg-white flex items-center justify-center font-bold text-lg">

                                    -

                                </button>

                                <span class="qty-text font-bold min-w-[20px] text-center text-lg">

                                    <?= $item['qty'] ?>

                                </span>

                                <button
                                    onclick="updateQty(<?= $item['id'] ?>, 'increase')"
                                    class="w-9 h-9 rounded-xl bg-[#EF7722] text-white flex items-center justify-center font-bold text-lg">

                                    +

                                </button>

                            </div>

                        </div>

                    </div>

                <?php endforeach; ?>

            </div>

            <!-- RIGHT -->
            <div>

                <div class="bg-white rounded-3xl p-6 lg:sticky lg:top-24">

                    <h3 class="text-2xl font-bold mb-6">
                        Rincian Pembayaran
                    </h3>

                    <!-- SUBTOTAL -->
                    <div class="flex justify-between items-center mb-5">

 						<span id="subtotalText" class="text-gray-500">

                            Subtotal
                            (<?= array_sum(array_column($cart, 'qty')) ?> menu)

                        </span>

                        <span id="subtotalPrice" class="font-semibold">

                            Rp<?= number_format($subtotal,0,',','.') ?>

                        </span>

                    </div>

                    <!-- OTHER FEES -->
                    <div class="border border-gray-200 rounded-2xl p-4 mb-5">

                        <button
                            onclick="toggleFeeDetail()"
                            class="w-full flex items-center justify-between">

                            <div class="flex items-center gap-2">
                                

                                <span class="text-gray-500">
                                    Biaya Lainnya
                                </span>

                                <span id="feeArrow"
                                      class="text-[#EF7722] font-bold text-lg">

                                    +

                                </span>

                            </div>
							
                            <span id="feePrice" class="font-semibold">

                                Rp<?= number_format($ppn + $service,0,',','.') ?>

                            </span>

                        </button>

                        <div id="feeDetail"
                             class="hidden mt-5 pt-5 border-t border-gray-100 space-y-4">

                            <div class="flex items-center justify-between text-sm">

                                <span class="text-gray-500">
                                    
                                    PPN 11%
                                </span>

                                <span id="ppnPrice" class="font-medium">

                                    Rp<?= number_format($ppn,0,',','.') ?>

                                </span>

                            </div>

                            <div class="flex items-center justify-between text-sm">

                                <span class="text-gray-500">
                                    Service 5%
                                </span>

                                <span id="servicePrice" class="font-medium">

                                    Rp<?= number_format($service,0,',','.') ?>

                                </span>

                            </div>

                        </div>

                    </div>

                    <div class="border-t border-gray-200 pt-5 mb-6">

                        <div class="flex justify-between items-center">

                            <span class="text-xl font-bold">
                                Total
                            </span>

                            <span class="grandTotal text-3xl font-bold text-[#EF7722]">

                                Rp<?= number_format($grandTotal,0,',','.') ?>

                            </span>

                        </div>

                    </div>
                    
                    <a href="<?= base_url('checkout') ?>"
                       class="w-full bg-[#EF7722] hover:bg-[#FAA533] transition text-white h-14 rounded-2xl hidden lg:flex items-center justify-center font-semibold text-lg">

                        Pembayaran

                    </a>

                </div>

            </div>

        </div>

    <?php endif; ?>

</div>

<?php if(!empty($cart)): ?>

    <div class="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-4 py-4 lg:hidden z-50">

        <div class="flex items-center justify-between gap-4 mb-4">

            <div>

                <p class="text-sm text-gray-500 mb-1">
                    Total Pembayaran
                </p>

                <h3 class="grandTotal text-3xl font-bold text-[#EF7722] leading-none">

                    Rp<?= number_format($grandTotal,0,',','.') ?>

                </h3>

            </div>

            <button
                onclick="toggleFeeDetail()"
                class="text-sm font-semibold text-[#EF7722]">

                Detail

            </button>

        </div>

        <a href="<?= base_url('checkout') ?>"
           class="w-full bg-[#EF7722] hover:bg-[#FAA533] transition text-white h-14 rounded-2xl flex items-center justify-center font-semibold text-lg">

            Lanjut Pembayaran

        </a>

    </div>

<?php endif; ?>

<button
    id="goTopBtn"
    onclick="scrollToTop()"
    class="fixed bottom-[170px] right-5 w-11 h-11 rounded-full bg-[#EF7722] text-white shadow-lg hidden items-center justify-center z-50 hover:scale-110 transition-all duration-300">

    <svg xmlns="http://www.w3.org/2000/svg"
         class="w-5 h-5"
         fill="none"
         viewBox="0 0 24 24"
         stroke="currentColor">

        <path stroke-linecap="round"
              stroke-linejoin="round"
              stroke-width="2"
              d="M5 15l7-7 7 7"/>

    </svg>

</button>

<script>

const goTopBtn =
    document.getElementById('goTopBtn');

window.addEventListener('scroll', () => {

    if(window.scrollY > 400){

        goTopBtn.classList.remove('hidden');
        goTopBtn.classList.add('flex');

    } else {

        goTopBtn.classList.remove('flex');
        goTopBtn.classList.add('hidden');

    }

});

function scrollToTop()
{
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
}

</script>

<script>

const PPN_RATE = 0.11;
const SERVICE_RATE = 0.05;

function rupiah(number)
{
    return 'Rp' + Number(number)
        .toLocaleString('id-ID');
}

function toggleFeeDetail()
{
    const detail = document.getElementById('feeDetail');
    const arrow = document.getElementById('feeArrow');

    detail.classList.toggle('hidden');

    arrow.innerHTML =
        detail.classList.contains('hidden')
        ? '+'
        : '-';
}

function recalculateCart()
{
    let subtotal = 0;
    let totalMenu = 0;

    document.querySelectorAll('.cart-item').forEach(item => {

        const price =
            parseInt(item.dataset.price);

        const qty =
            parseInt(
                item.querySelector('.qty-text')
                .innerHTML
            );

        subtotal += price * qty;
        totalMenu += qty;
        
        
            
             const cartCount =
                document.getElementById('cartCount');

            if(cartCount){

                cartCount.innerHTML =
                    totalMenu;

            }

    });

    const ppn = subtotal * PPN_RATE;
    const service = subtotal * SERVICE_RATE;
    const grandTotal = subtotal + ppn + service;

    document.getElementById('subtotalText')
        .innerHTML =
        `Subtotal (${totalMenu} menu)`;

    document.getElementById('subtotalPrice')
        .innerHTML =
        rupiah(subtotal);

    document.getElementById('feePrice')
        .innerHTML =
        rupiah(ppn + service);

    document.getElementById('ppnPrice')
        .innerHTML =
        rupiah(ppn);

    document.getElementById('servicePrice')
        .innerHTML =
        rupiah(service);

    document.querySelectorAll('.grandTotal')
        .forEach(el => {

            el.innerHTML =
                rupiah(grandTotal);

        });

    if(totalMenu <= 0){

        location.reload();

    }
}

async function updateQty(id, type)
{
    try {

        const response = await fetch(
            `<?= base_url('cart') ?>/${type}/${id}`
        );

        const result = await response.json();

        if(result.status){

            const qtyElement =
                document.querySelector(
                    `#cart-item-${id} .qty-text`
                );

            let qty =
                parseInt(qtyElement.innerHTML);

            if(type === 'increase'){

                qty++;

            } else {

                qty--;

            }

            if(qty <= 0){

                document
                .getElementById(`cart-item-${id}`)
                .remove();

            } else {

                qtyElement.innerHTML = qty;

            }

            recalculateCart();

        }

    } catch(err){

        console.log(err);

    }
}

async function removeCart(id)
{
    try {

        const response = await fetch(
            `<?= base_url('cart/remove') ?>/${id}`
        );

        const result = await response.json();

        if(result.status){

            document
            .getElementById(`cart-item-${id}`)
            .remove();

            recalculateCart();
            
             const cartCount =
                document.getElementById('cartCount');

            if(cartCount){

                cartCount.innerHTML =
                    result.count;

            }

        }

    } catch(err){

        console.log(err);

    }
}

</script>