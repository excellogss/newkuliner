<?= $this->include('layout/header') ?>
                    <div class="flex items-center justify-between">
                    </div>

                </div>

            </div>

            <div class="bg-white rounded-3xl p-6 mt-5 text-center">

                <h3 class="text-2xl font-bold mb-3">
                    Pembayaran QRIS
                </h3>

                <p class="text-gray-500 mb-8">
                    Scan QR berikut untuk melakukan pembayaran
                </p>

                <img src="https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=NEWKULINER"
                     class="w-full max-w-[320px] mx-auto rounded-3xl border border-gray-200 p-4 bg-white">
                
                <div class="items-center justify-between mt-2">

                        <span class="text-3xl font-bold text-[#EF7722]">
                            Rp<?= number_format($total,0,',','.') ?>
                        </span>

                    </div>

                <div class="bg-[#EBEBEB] rounded-3xl p-5 mt-8 text-left">

                    <div class="flex justify-between mb-3">
                        <span class="text-gray-500">Customer</span>
                        <span class="font-semibold">
                            <?= session()->get('customer_name') ?? 'Guest' ?>
                        </span>
                    </div>

                    <div class="flex justify-between mb-3">
                        <span class="text-gray-500">Nomor HP</span>
                        <span class="font-semibold">
                            <?= session()->get('customer_phone') ?? '-' ?>
                        </span>
                    </div>

                    <div class="flex justify-between">
                        <span class="text-gray-500">Metode</span>
                        <span class="font-semibold">QRIS</span>
                    </div>

                </div>

                <form action="<?= base_url('checkout/process') ?>"
                      method="post"
                      class="mt-8">

                    <?= csrf_field() ?>

                    <button type="submit"
                            class="w-full bg-[#EF7722] hover:bg-[#FAA533] transition text-white h-14 rounded-2xl font-semibold text-lg">

                        Saya Sudah Bayar

                    </button>

                </form>

            </div>

        </div>

    </div>

</div>

<?= $this->include('layout/footer') ?>