<?= $this->include('layout/header') ?>
<?php if(!session()->get('customer_name')): ?>

    <?= $this->include('components/customer_modal') ?>

<?php endif; ?>

<section class="relative min-h-[250px] overflow-hidden">

    <img
        src="https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=1400&q=80"
        class="absolute inset-0 w-full h-full object-cover"
    >

    <div class="absolute inset-0 bg-black/60"></div>

    <div class="relative z-10 container mx-auto px-4 min-h-[250px] flex items-center">

        <div class="w-full text-white">

            <!-- span class="bg-[#FAA533]/20 border border-[#FAA533]/30 px-5 py-2 rounded-full inline-flex mb-6 backdrop-blur-sm">
                🍽️ Restaurant Premium
            </span -->

            <h1 class="text-5xl md:text-7xl font-bold leading-tight max-w-3xl">
                <span class="text-[#FAA533]">
                    Ayo Kuliner
                </span>
            </h1>

            <p class="text-lg text-gray-200 leading-relaxed mb-8 max-w-2xl">
                Sub Newkuliner
            </p>

            <div class="w-full text-center">

                <div class="w-full bg-white/10 backdrop-blur-md border border-white/20 text-white px-6 py-5 rounded-3xl">

                    <p class="text-sm text-gray-200 mb-2">
                        Meja
                    </p>

                    <h3 class="text-3xl font-bold text-[#FAA533]">
                        Meja 01
                    </h3>

                </div>

            </div>

        </div>

    </div>

</section>

<section class="container mx-auto px-4 py-8">

    <div class="grid md:grid-cols-4 gap-6">

        <div class="bg-white rounded-3xl p-6 shadow-sm">
            <h3 class="font-bold text-lg mb-2">Alamat</h3>
            <p class="text-gray-600">Jl. Kuliner Nusantara No.88</p>
        </div>

        <div class="bg-white rounded-3xl p-6 shadow-sm">
            <h3 class="font-bold text-lg mb-2">Jam Operasional</h3>
            <p class="text-gray-600">09:00 - 22:00 WIB</p>
        </div>

        <div class="bg-white rounded-3xl p-6 shadow-sm">
            <h3 class="font-bold text-lg mb-2">WhatsApp</h3>
            <p class="text-gray-600">0812-3456-7890</p>
        </div>

    </div>

</section>

<section id="menu" class="container mx-auto px-4 pb-20">

    <!-- div class="flex items-center justify-between mb-8 flex-wrap gap-4">

        <div>
            <h2 class="text-4xl font-bold mb-2">
                Menu Pilihan
            </h2>

            <p class="text-gray-500">
                Pilih menu favoritmu
            </p>
        </div>

        <a href="<?= base_url('cart') ?>"
           class="bg-[#EF7722] text-white px-5 py-3 rounded-2xl font-semibold hover:bg-[#FAA533] transition">
            Lihat Cart
        </a>

    </div -->
    
    <div class="mb-10">

        <div class="relative">

            <input
                type="text"
                id="searchProduct"
                placeholder="Cari menu favorit..."
                class="w-full bg-white rounded-2xl h-14 pl-14 pr-5 outline-none border-2 border-transparent focus:border-[#EF7722]"
            >

            <svg xmlns="http://www.w3.org/2000/svg"
                 class="w-6 h-6 absolute left-5 top-1/2 -translate-y-1/2 text-gray-400"
                 fill="none"
                 viewBox="0 0 24 24"
                 stroke="currentColor">

                <path stroke-linecap="round"
                      stroke-linejoin="round"
                      stroke-width="2"
                      d="M21 21l-4.35-4.35m1.85-5.15a7 7 0 11-14 0 7 7 0 0114 0z"/>

            </svg>

        </div>

    </div>

    <div class="flex gap-3 overflow-x-auto pb-5 mb-10 pt-5 no-scrollbar sticky top-[72px] bg-[#EBEBEB] z-20">

        <button
            class="category-btn active whitespace-nowrap bg-[#EF7722] text-white px-6 py-3 rounded-full font-semibold"
            data-category="Makanan">
            Makanan
        </button>

        <button
            class="category-btn whitespace-nowrap bg-white px-6 py-3 rounded-full font-semibold"
            data-category="Minuman">
            Minuman
        </button>

        <button
            class="category-btn whitespace-nowrap bg-white px-6 py-3 rounded-full font-semibold"
            data-category="Snack">
            Snack
        </button>

        <button
            class="category-btn whitespace-nowrap bg-white px-6 py-3 rounded-full font-semibold"
            data-category="Dessert">
            Dessert
        </button>

        <button
            class="category-btn whitespace-nowrap bg-white px-6 py-3 rounded-full font-semibold"
            data-category="Sauce">
            Sauce
        </button>

    </div>

    <div class="category-section mb-16" id="Makanan">

            <div class="flex items-center gap-4 mb-8">

                <h3 class="text-3xl font-bold whitespace-nowrap">
                    Makanan
                </h3>

                <div class="w-full h-[2px] bg-[#EF7722] rounded-full"></div>

            </div>

            <div class="grid grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">

            <?php foreach($products as $product): ?>

                <?php if($product['category'] == 'Makanan'): ?>

                    <div class="bg-white rounded-3xl overflow-hidden shadow-sm product-item flex flex-col h-full hover:-translate-y-2 transition-all duration-300" data-name="<?= strtolower($product['name']) ?>" >

                        <img
                            src="<?= $product['image'] ?>"
                             class="w-full h-36 md:h-56 object-cover"
                        >

                        <div class="p-6">

                            <div class="flex justify-between gap-3 mb-3">

                                <h3 class="font-bold text-base md:text-2xl leading-tight mb-2 line-clamp-2 min-h-[48px] md:min-h-[64px]">
                                    <?= $product['name'] ?>
                                </h3>

                            </div>

                            <p class="text-gray-500 text-sm md:text-base mb-5 line-clamp-2">
                                <?= $product['description'] ?>
                            </p>

                            <div class="mt-auto">

    							<h4 class="text-lg md:text-2xl font-bold text-[#EF7722] mb-4">
                                    Rp<?= number_format($product['price'],0,',','.') ?>
                                </h4>

                                <button
                                    onclick="openAddCart(
                                        '<?= $product['id'] ?>',
                                        '<?= $product['name'] ?>',
                                        '<?= number_format($product['price'],0,',','.') ?>'
                                    )"
                                    class="w-full flex items-center justify-center bg-[#EF7722] hover:bg-[#FAA533] text-white h-11 md:h-12 rounded-2xl text-sm md:text-base font-semibold transition">
                                    Tambah
                                </button>

                            </div>

                        </div>

                    </div>

                <?php endif; ?>

            <?php endforeach; ?>

        </div>

    </div>

    <div class="category-section mb-16" id="Minuman">

        <div class="flex items-center gap-4 mb-8">

			<h3 class="text-3xl font-bold whitespace-nowrap">
				Minuman
			</h3>

			<div class="w-full h-[2px] bg-[#EF7722] rounded-full"></div>

		</div>

            <div class="grid grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">

            <?php foreach($products as $product): ?>

                <?php if($product['category'] == 'Minuman'): ?>

                    <div class="bg-white rounded-3xl overflow-hidden shadow-sm product-item flex flex-col h-full hover:-translate-y-2 transition-all duration-300" data-name="<?= strtolower($product['name']) ?>" >

                        <img
                            src="<?= $product['image'] ?>"
                             class="w-full h-36 md:h-56 object-cover"
                        >

                        <div class="p-6">

                            <div class="flex justify-between gap-3 mb-3">

                                <h3 class="font-bold text-base md:text-2xl leading-tight mb-2 line-clamp-2 min-h-[48px] md:min-h-[64px]">
                                    <?= $product['name'] ?>
                                </h3>

                            </div>

                            <p class="text-gray-500 text-sm md:text-base mb-5 line-clamp-2">
                                <?= $product['description'] ?>
                            </p>

                            <div class="mt-auto">

    							<h4 class="text-lg md:text-2xl font-bold text-[#EF7722] mb-4">
                                    
                                    Rp<?= number_format($product['price'],0,',','.') ?>
                                </h4>

                                <button
                                    onclick="openAddCart(
                                        '<?= $product['id'] ?>',
                                        '<?= $product['name'] ?>',
                                        '<?= number_format($product['price'],0,',','.') ?>'
                                    )"
                                     class="w-full flex items-center justify-center bg-[#EF7722] hover:bg-[#FAA533] text-white h-11 md:h-12 rounded-2xl text-sm md:text-base font-semibold transition">
                                    Tambah
                                </button>

                            </div>

                        </div>

                    </div>

                <?php endif; ?>

            <?php endforeach; ?>

        </div>

    </div>

    <div class="category-section" id="Snack">
	
		<div class="flex items-center gap-4 mb-8">

			<h3 class="text-3xl font-bold whitespace-nowrap">
				Snack
			</h3>

			<div class="w-full h-[2px] bg-[#EF7722] rounded-full"></div>

		</div>

            <div class="grid grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">

            <?php foreach($products as $product): ?>

                <?php if($product['category'] == 'Snack'): ?>

                    <div class="bg-white rounded-3xl overflow-hidden shadow-sm product-item flex flex-col h-full hover:-translate-y-2 transition-all duration-300" data-name="<?= strtolower($product['name']) ?>" >

                        <img
                            src="<?= $product['image'] ?>"
                             class="w-full h-36 md:h-56 object-cover"
                        >

                        <div class="p-6">

                            <div class="flex justify-between gap-3 mb-3">

                                <h3 class="font-bold text-base md:text-2xl leading-tight mb-2 line-clamp-2 min-h-[48px] md:min-h-[64px]">
                                    <?= $product['name'] ?>
                                </h3>

                            </div>

                            <p class="text-gray-500 text-sm md:text-base mb-5 line-clamp-2">
                                <?= $product['description'] ?>
                            </p>

                            <div class="mt-auto">

    							<h4 class="text-lg md:text-2xl font-bold text-[#EF7722] mb-4">
                                    Rp<?= number_format($product['price'],0,',','.') ?>
                                </h4>

                                <button
                                    onclick="openAddCart(
                                        '<?= $product['id'] ?>',
                                        '<?= $product['name'] ?>',
                                        '<?= number_format($product['price'],0,',','.') ?>'
                                    )"
                                    class="w-full flex items-center justify-center bg-[#EF7722] hover:bg-[#FAA533] text-white h-11 md:h-12 rounded-2xl text-sm md:text-base font-semibold transition">
                                    Tambah
                                </button>

                            </div>

                        </div>

                    </div>

                <?php endif; ?>

            <?php endforeach; ?>

        </div>

    </div>

</section>

<div
    id="addCartModal"
    class="fixed inset-0 bg-black/50 z-50 hidden items-center justify-center p-4"
>

    <div class="bg-white w-full max-w-lg rounded-3xl p-8 relative">

        <button
            onclick="closeAddCart()"
            class="absolute top-4 right-4 text-2xl text-gray-500">
            ×
        </button>

        <h2 id="modalTitle"
            class="text-3xl font-bold mb-2"></h2>

        <p id="modalPrice"
           class="text-[#EF7722] text-2xl font-bold mb-8"></p>

		<form id="addCartForm" action="<?= base_url('cart/add') ?>" method="post">

            <?= csrf_field() ?>

            <input type="hidden" name="id" id="modalProductId">

            <div class="mb-6">

                <label class="block font-semibold mb-4">
                    Tambahan Menu
                </label>

                <div class="space-y-3">

                    <label class="flex justify-between items-center border rounded-2xl p-4">

                        <div class="flex items-center gap-3">
                            <input type="checkbox" name="extra[]" value="Extra Sambal">
                            <span>Extra Sambal</span>
                        </div>

                        <span class="font-semibold text-[#EF7722]">
                            +Rp5.000
                        </span>

                    </label>

                    <label class="flex justify-between items-center border rounded-2xl p-4">

                        <div class="flex items-center gap-3">
                            <input type="checkbox" name="extra[]" value="Extra Cheese">
                            <span>Extra Cheese</span>
                        </div>

                        <span class="font-semibold text-[#EF7722]">
                            +Rp10.000
                        </span>

                    </label>

                </div>

            </div>

            <div class="mb-8">

                <label class="block font-semibold mb-3">
                    Catatan
                </label>

                <textarea
                    name="note"
                    rows="4"
                    class="w-full border rounded-2xl p-4"
                    placeholder="Contoh: tidak pedas"></textarea>

            </div>

            <button
                type="submit"
                class="w-full bg-[#EF7722] hover:bg-[#FAA533] transition text-white py-4 rounded-2xl font-semibold text-lg">
                Tambah Pesanan
            </button>

        </form>

    </div>

</div>

<script>

const sections = document.querySelectorAll('.category-section');
const buttons = document.querySelectorAll('.category-btn');

window.addEventListener('scroll', () => {

    let current = '';

    sections.forEach(section => {

        const top = section.offsetTop;

        if(scrollY >= top - 200){

            current = section.getAttribute('id');

        }

    });

    buttons.forEach(btn => {

        btn.classList.remove('bg-[#EF7722]', 'text-white');
        btn.classList.add('bg-white');

        if(btn.dataset.category == current){

            btn.classList.remove('bg-white');
            btn.classList.add('bg-[#EF7722]', 'text-white');

        }

    });

});

buttons.forEach(btn => {

    btn.addEventListener('click', () => {

        const category = btn.dataset.category;

        const target = document.getElementById(category);

        const y =
            target.getBoundingClientRect().top +
            window.pageYOffset -
            170;

        window.scrollTo({
            top: y,
            behavior: 'smooth'
        });

    });

});

function openAddCart(id, name, price)
{
    const modal = document.getElementById('addCartModal');

    modal.classList.remove('hidden');
    modal.classList.add('flex');

    document.getElementById('modalProductId').value = id;
    document.getElementById('modalTitle').innerHTML = name;
    document.getElementById('modalPrice').innerHTML = 'Rp' + price;

    document
    .querySelectorAll('#addCartModal input[type="checkbox"]')
    .forEach(item => {

        item.checked = false;

    });

    document.querySelector('#addCartModal textarea').value = '';
}

function closeAddCart()
{
    const modal = document.getElementById('addCartModal');

    modal.classList.add('hidden');
    modal.classList.remove('flex');
}

const searchInput =
    document.getElementById('searchProduct');

searchInput.addEventListener('keyup', function(){

    const value = this.value.toLowerCase();

    document.querySelectorAll('.product-item')
    .forEach(item => {

        const name = item.dataset.name;

        if(name.includes(value)){

            item.style.display = 'block';

        } else {

            item.style.display = 'none';

        }

    });

});


// AJAX ADD CART
const addCartForm =
    document.getElementById('addCartForm');

addCartForm.addEventListener('submit', async function(e){

    e.preventDefault();

    const button =
        this.querySelector('button[type="submit"]');

    try {

        button.disabled = true;

        button.innerHTML =
            'Menambahkan...';

        const formData =
            new FormData(this);

        const response = await fetch(
            this.action,
            {
                method: 'POST',
                body: formData
            }
        );

        const result =
            await response.json();

        if(result.status){
            const cartCount =
                document.getElementById('cartCount');

            if(cartCount){

                cartCount.innerHTML =
                    result.count;

            }

            if(result.token){

                const csrfInput =
                    document.querySelector(
                        '#addCartForm input[name="<?= csrf_token() ?>"]'
                    );

                if(csrfInput){

                    csrfInput.value =
                        result.token;

                }

            }

            closeAddCart();

            showToast(
                'Pesanan berhasil ditambahkan'
            );

        }

    } catch(err){

        console.log(err);

    } finally {

        button.disabled = false;

        button.innerHTML =
            'Tambah Pesanan';

    }

});

function showToast(message)
{
    let toast =
        document.getElementById('toastNotif');

    if(!toast){

        toast =
            document.createElement('div');

        toast.id = 'toastNotif';

        toast.className =
            'fixed left-1/2 -translate-x-1/2 bottom-24 bg-white border border-gray-200 text-gray-700 px-4 py-3 rounded-2xl shadow-xl z-[9999] flex items-center gap-2 opacity-0 translate-y-5 transition-all duration-300';

        document.body.appendChild(toast);

    }

    toast.innerHTML = `
        <div class="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center shrink-0">

            <svg xmlns="http://www.w3.org/2000/svg"
                 class="w-4 h-4 text-green-600"
                 fill="none"
                 viewBox="0 0 24 24"
                 stroke="currentColor">

                <path stroke-linecap="round"
                      stroke-linejoin="round"
                      stroke-width="2"
                      d="M5 13l4 4L19 7"/>

            </svg>

        </div>

        <p class="font-medium text-sm whitespace-nowrap">
            ${message}
        </p>
    `;

    toast.classList.remove(
        'opacity-0',
        'translate-y-5'
    );

    toast.classList.add(
        'opacity-100',
        'translate-y-0'
    );

    clearTimeout(window.toastTimeout);

    window.toastTimeout = setTimeout(() => {

        toast.classList.remove(
            'opacity-100',
            'translate-y-0'
        );

        toast.classList.add(
            'opacity-0',
            'translate-y-5'
        );

    }, 2200);
}

</script>
<?= $this->include('layout/footer') ?>