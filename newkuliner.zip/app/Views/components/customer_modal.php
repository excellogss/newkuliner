<div id="customerModal"
     class="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">

    <div class="bg-white w-full max-w-md rounded-3xl p-8 relative">

        <button onclick="closeModal()"
                class="absolute top-4 right-4 text-2xl text-gray-500">
            ×
        </button>

        <h2 class="text-3xl font-bold mb-2">
            Selamat Datang 👋
        </h2>

        <p class="text-gray-500 mb-8">
            Isi data terlebih dahulu sebelum memesan
        </p>

        <form action="<?= base_url('save-customer') ?>"
              method="post">

            <div class="mb-5">
                <label class="block mb-2 font-medium">
                    Nama *
                </label>

                <input type="text" name="name"
                       required
                       class="w-full border rounded-2xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-[#EF7722]">
            </div>

            <div class="mb-8">
                <label class="block mb-2 font-medium">
                    No HP (Optional)
                </label>

                <input type="text"
                       class="w-full border rounded-2xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-[#EF7722]">
            </div>

            <button type="submit" name="nohp"
                    class="w-full bg-[#EF7722] hover:bg-[#FAA533] transition text-white py-4 rounded-2xl font-semibold">
                Mulai Pesan
            </button>

        </form>

    </div>

</div>

<script>
function closeModal() {
    document.getElementById('customerModal').style.display = 'none';
}
</script>