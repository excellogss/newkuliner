<?php

namespace App\Controllers;

use App\Models\ProductModel;

class Product extends BaseController
{
    public function index()
    {
        $model = new ProductModel();

        return view('products', [
            'products' => $model->getProducts()
        ]);
    }

    public function detail($id)
    {
        $model = new ProductModel();

        $product = $model->getProduct($id);

        if (!$product) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        return view('product_detail', [
            'product' => $product,
            'products' => $model->getProducts()
        ]);
    }
}