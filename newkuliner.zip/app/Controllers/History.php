<?php

namespace App\Controllers;

class History extends BaseController
{
    public function index()
    {
        $transactions = [

            [
                'invoice' => 'INV-20260522001',
                'customer_name' => 'Budi',
                'total' => 85000,
                'status' => 'PAID',
                'created_at' => '22 Mei 2026 08:30',
                'items' => [

                    [
                        'name' => 'Nasi Goreng Special',
                        'qty' => 2,
                        'price' => 25000
                    ],

                    [
                        'name' => 'Es Teh Manis',
                        'qty' => 1,
                        'price' => 10000
                    ],

                    [
                        'name' => 'Kentang Goreng',
                        'qty' => 1,
                        'price' => 25000
                    ]

                ]
            ],

            [
                'invoice' => 'INV-20260522002',
                'customer_name' => 'Sinta',
                'total' => 56000,
                'status' => 'PENDING',
                'created_at' => '22 Mei 2026 09:10',
                'items' => [

                    [
                        'name' => 'Mie Ayam',
                        'qty' => 2,
                        'price' => 18000
                    ],

                    [
                        'name' => 'Jus Jeruk',
                        'qty' => 1,
                        'price' => 20000
                    ]

                ]
            ]

        ];

        return view('history', [
            'transactions' => $transactions
        ]);
    }
}