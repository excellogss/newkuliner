<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\ProductModel;

class Checkout extends BaseController
{
    public function index()
    {
        $cart = session()->get('cart') ?? [];

        $total = 0;

        foreach($cart as $item){

            $total += $item['price'] * $item['qty'];

        }

        return view('checkout', [
            'cart'  => $cart,
            'total' => $total
        ]);
    }

    public function process()
    {
        session()->remove('cart');

        return redirect()->to('/');
    }
}