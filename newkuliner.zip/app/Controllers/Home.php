<?php

namespace App\Controllers;

use App\Models\ProductModel;

class Home extends BaseController
{
    public function index()
    {
        $model = new ProductModel();

        $data['products'] = $model->getProducts();

        return view('home', $data);
    }
    
    public function saveCustomer()
    {
        $name = $this->request->getPost('name');
        $phone = $this->request->getPost('nohp');

        session()->set([
            'customer_name'  => $name,
            'customer_phone' => $phone
        ]);

        return redirect()->to(base_url());
    }
}