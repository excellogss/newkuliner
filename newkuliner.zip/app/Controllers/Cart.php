<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\ProductModel;

class Cart extends BaseController
{
    public function index()
    {
        $cart = session()->get('cart') ?? [];

        $total = 0;

        foreach($cart as $item){

            $total += $item['price'] * $item['qty'];

        }

        return view('cart', [
            'cart'  => $cart,
            'total' => $total
        ]);
    }

    public function add()
    {
        $id = $this->request->getPost('id');

        if(!$id){

            return $this->response->setJSON([
                'status' => false
            ]);

        }

        $model = new ProductModel();

        $product = $model->getProduct($id);

        if(!$product){

            return $this->response->setJSON([
                'status' => false
            ]);

        }

        $cart = session()->get('cart') ?? [];

        if(isset($cart[$id])){

            $cart[$id]['qty']++;

        } else {

            $cart[$id] = [
                'id'    => $product['id'],
                'name'  => $product['name'],
                'price' => $product['price'],
                'image' => $product['image'],
                'qty'   => 1,
                'note'  => $this->request->getPost('note')
            ];

        }

        session()->set('cart', $cart);

        return $this->response->setJSON([
            'status' => true,
            'count'  => count($cart),
            'token'  => csrf_hash()
        ]);
    }

    public function increase($id)
    {
        $cart = session()->get('cart') ?? [];

        if(isset($cart[$id])){

            $cart[$id]['qty']++;

            session()->set('cart', $cart);

        }

        return $this->response->setJSON([
            'status' => true
        ]);
    }

    public function decrease($id)
    {
        $cart = session()->get('cart') ?? [];

        if(isset($cart[$id])){

            $cart[$id]['qty']--;

            if($cart[$id]['qty'] <= 0){

                unset($cart[$id]);

            }

            session()->set('cart', $cart);

        }

        return $this->response->setJSON([
            'status' => true
        ]);
    }

    public function remove($id)
    {
        $cart = session()->get('cart') ?? [];

        if(isset($cart[$id])){

            unset($cart[$id]);

            session()->set('cart', $cart);

        }

        return $this->response->setJSON([
            'status' => true
        ]);
    }

    public function checkout()
    {
        $cart = session()->get('cart') ?? [];

        $total = 0;

        foreach($cart as $item){

            $total += $item['price'] * $item['qty'];

        }

        return view('checkout', [
            'cart'  => $cart,
            'total' => $total
        ]);
    }

    public function processCheckout()
    {
        $cart = session()->get('cart') ?? [];

        if(empty($cart)){

            return redirect()->to('/cart');

        }

        $history = session()->get('history') ?? [];

        $total = 0;

        foreach($cart as $item){

            $total += $item['price'] * $item['qty'];

        }

        $history[] = [
            'invoice' => 'INV-'.time(),
            'date'    => date('d M Y H:i'),
            'items'   => $cart,
            'total'   => $total
        ];

        session()->set('history', $history);

        session()->remove('cart');

        return redirect()->to('/history');
    }

    public function history()
    {
        $history = session()->get('history') ?? [];

        return view('history', [
            'history' => array_reverse($history)
        ]);
    }
}