<?php

namespace App\Models;

use CodeIgniter\Model;

class ProductModel extends Model
{
    public function getProducts()
    {
        return [
            [
                'id' => 1,
                'name' => 'Nasi Goreng Spesial',
                'category' => 'Makanan',
                'price' => 35000,
                'description' => 'Nasi spesial.',
                'image' => 'https://images.unsplash.com/photo-1604908176997-125f25cc6f3d?w=600&q=80'
            ],

            [
                'id' => 2,
                'name' => 'Mie Ayam Bakso',
                'category' => 'Makanan',
                'price' => 28000,
                'description' => 'Mie ayam.',
                'image' => 'https://images.unsplash.com/photo-1612929633738-8fe44f7ec841?w=600&q=80'
            ],

            [
                'id' => 3,
                'name' => 'Ayam Geprek',
                'category' => 'Makanan',
                'price' => 30000,
                'description' => 'Ayam crispy.',
                'image' => 'https://images.unsplash.com/photo-1562967916-eb82221dfb92?w=600&q=80'
            ],

            [
                'id' => 4,
                'name' => 'Sate Ayam',
                'category' => 'Makanan',
                'price' => 32000,
                'description' => 'bumbu kacang.',
                'image' => 'https://images.unsplash.com/photo-1529563021893-cc83c992d75d?w=600&q=80'
            ],

            [
                'id' => 5,
                'name' => 'Beef Burger',
                'category' => 'Makanan',
                'price' => 45000,
                'description' => 'Burger premium.',
                'image' => 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=600&q=80'
            ],

            [
                'id' => 6,
                'name' => 'Chicken Steak',
                'category' => 'Makanan',
                'price' => 50000,
                'description' => 'saus mushroom.',
                'image' => 'https://images.unsplash.com/photo-1544025162-d76694265947?w=600&q=80'
            ],


            [
                'id' => 7,
                'name' => 'Es Teh Manis',
                'category' => 'Minuman',
                'price' => 10000,
                'description' => 'Es segar.',
                'image' => 'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?w=600&q=80'
            ],

            [
                'id' => 8,
                'name' => 'Cappuccino',
                'category' => 'Minuman',
                'price' => 22000,
                'description' => 'Kopi creamy.',
                'image' => 'https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=600&q=80'
            ],

            [
                'id' => 9,
                'name' => 'Matcha Latte',
                'category' => 'Minuman',
                'price' => 26000,
                'description' => 'Minuman premium.',
                'image' => 'https://images.unsplash.com/photo-1515823064-d6e0c04616a7?w=600&q=80'
            ],

            [
                'id' => 10,
                'name' => 'Thai Tea',
                'category' => 'Minuman',
                'price' => 18000,
                'description' => 'Thai dingin.',
                'image' => 'https://images.unsplash.com/photo-1556679343-c7306c1976bc?w=600&q=80'
            ],

            [
                'id' => 11,
                'name' => 'Chocolate Milk',
                'category' => 'Minuman',
                'price' => 24000,
                'description' => 'Susu premium.',
                'image' => 'https://images.unsplash.com/photo-1577805947697-89e18249d767?w=600&q=80'
            ],

            [
                'id' => 12,
                'name' => 'Orange Juice',
                'category' => 'Minuman',
                'price' => 17000,
                'description' => 'Jus segar.',
                'image' => 'https://images.unsplash.com/photo-1603569283847-aa295f0d016a?w=600&q=80'
            ],

            [
                'id' => 13,
                'name' => 'French Fries',
                'category' => 'Snack',
                'price' => 20000,
                'description' => 'Kentang crispy.',
                'image' => 'https://images.unsplash.com/photo-1630384060421-cb20d0e0649d?w=600&q=80'
            ],

            [
                'id' => 14,
                'name' => 'Onion Ring',
                'category' => 'Snack',
                'price' => 22000,
                'description' => 'Onion crispy.',
                'image' => 'https://images.unsplash.com/photo-1639024471283-03518883512d?w=600&q=80'
            ],

            [
                'id' => 15,
                'name' => 'Chicken Wings',
                'category' => 'Snack',
                'price' => 35000,
                'description' => 'Chicken spicy.',
                'image' => 'https://images.unsplash.com/photo-1527477396000-e27163b481c2?w=600&q=80'
            ],

            [
                'id' => 16,
                'name' => 'Dimsum Mix',
                'category' => 'Snack',
                'price' => 28000,
                'description' => 'Dimsum isi 6.',
                'image' => 'https://images.unsplash.com/photo-1563245372-f21724e3856d?w=600&q=80'
            ],

            [
                'id' => 17,
                'name' => 'Nachos',
                'category' => 'Snack',
                'price' => 30000,
                'description' => 'Nachos keju.',
                'image' => 'https://images.unsplash.com/photo-1513456852971-30c0b8199d4d?w=600&q=80'
            ],

            [
                'id' => 18,
                'name' => 'Sosis Bakar',
                'category' => 'Snack',
                'price' => 18000,
                'description' => 'Sosis manis.',
                'image' => 'https://images.unsplash.com/photo-1550547660-d9450f859349?w=600&q=80'
            ],


            [
                'id' => 19,
                'name' => 'Chocolate Cake',
                'category' => 'Dessert',
                'price' => 28000,
                'description' => 'Cake lembut.',
                'image' => 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=600&q=80'
            ],

            [
                'id' => 20,
                'name' => 'Ice Cream Vanilla',
                'category' => 'Dessert',
                'price' => 22000,
                'description' => 'Ice cream premium.',
                'image' => 'https://images.unsplash.com/photo-1563805042-7684c019e1cb?w=600&q=80'
            ],

            [
                'id' => 21,
                'name' => 'Pancake Honey',
                'category' => 'Dessert',
                'price' => 30000,
                'description' => 'Pancake madu.',
                'image' => 'https://images.unsplash.com/photo-1528207776546-365bb710ee93?w=600&q=80'
            ],

            [
                'id' => 22,
                'name' => 'Cheese Cake',
                'category' => 'Dessert',
                'price' => 35000,
                'description' => 'Cheese creamy.',
                'image' => 'https://images.unsplash.com/photo-1533134242443-d4fd215305ad?w=600&q=80'
            ],

            [
                'id' => 23,
                'name' => 'Tiramisu',
                'category' => 'Dessert',
                'price' => 32000,
                'description' => 'Dessert premium.',
                'image' => 'https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?w=600&q=80'
            ],

            [
                'id' => 24,
                'name' => 'Brownies',
                'category' => 'Dessert',
                'price' => 25000,
                'description' => 'Brownies legit.',
                'image' => 'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?w=600&q=80'
            ],

            [
                'id' => 25,
                'name' => 'Udang Bakar',
                'category' => 'Seafood',
                'price' => 55000,
                'description' => 'Udang madu.',
                'image' => 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=600&q=80'
            ],

            [
                'id' => 26,
                'name' => 'Cumi Crispy',
                'category' => 'Seafood',
                'price' => 48000,
                'description' => 'Cumi gurih.',
                'image' => 'https://images.unsplash.com/photo-1544025162-d76694265947?w=600&q=80'
            ],

            [
                'id' => 27,
                'name' => 'Kepiting Saus Padang',
                'category' => 'Seafood',
                'price' => 85000,
                'description' => 'padang pedas.',
                'image' => 'https://images.unsplash.com/photo-1559847844-d721426d6edc?w=600&q=80'
            ],

            [
                'id' => 28,
                'name' => 'Ikan Bakar',
                'category' => 'Seafood',
                'price' => 65000,
                'description' => 'Ikan Spesial.',
                'image' => 'https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?w=600&q=80'
            ],

            [
                'id' => 29,
                'name' => 'Salmon Grill',
                'category' => 'Seafood',
                'price' => 90000,
                'description' => 'Salmon premium.',
                'image' => 'https://images.unsplash.com/photo-1467003909585-2f8a72700288?w=600&q=80'
            ],

            [
                'id' => 30,
                'name' => 'Lobster Butter',
                'category' => 'Seafood',
                'price' => 120000,
                'description' => 'Lobster butter.',
                'image' => 'https://images.unsplash.com/photo-1559847844-5315695dadae?w=600&q=80'
            ],
            
            [
                'id' => 31,
                'name' => 'Americano',
                'category' => 'Kopi',
                'price' => 20000,
                'description' => 'Americano premium.',
                'image' => 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=600&q=80'
            ],

            [
                'id' => 32,
                'name' => 'Latte',
                'category' => 'Kopi',
                'price' => 24000,
                'description' => 'Latte creamy.',
                'image' => 'https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=600&q=80'
            ],

            [
                'id' => 33,
                'name' => 'Mocha',
                'category' => 'Kopi',
                'price' => 26000,
                'description' => 'Mocha chocolate.',
                'image' => 'https://images.unsplash.com/photo-1511920170033-f8396924c348?w=600&q=80'
            ],

            [
                'id' => 34,
                'name' => 'Espresso',
                'category' => 'Kopi',
                'price' => 18000,
                'description' => 'Espresso strong.',
                'image' => 'https://images.unsplash.com/photo-1497636577773-f1231844b336?w=600&q=80'
            ],

            [
                'id' => 35,
                'name' => 'Caramel Latte',
                'category' => 'Kopi',
                'price' => 28000,
                'description' => 'Latte caramel.',
                'image' => 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=600&q=80'
            ],

            [
                'id' => 36,
                'name' => 'Hazelnut Coffee',
                'category' => 'Kopi',
                'price' => 30000,
                'description' => 'Kopi hazelnut.',
                'image' => 'https://images.unsplash.com/photo-1521305916504-4a1121188589?w=600&q=80'
            ],

        ];
    }

    public function getProduct($id)
    {
        foreach ($this->getProducts() as $product) {

            if ($product['id'] == $id) {
                return $product;
            }

        }

        return null;
    }
}